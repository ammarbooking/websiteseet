# MAISON SUCRÉ — GitHub Pages

## Publish
1. Open your GitHub repository.
2. Upload `index.html` to the repository root (not inside a subfolder).
3. Go to Settings → Pages → Build and deployment → Deploy from a branch.
4. Choose `main` and `/(root)` and save.
5. Wait for deployment, then open the GitHub Pages URL.

The site is a static catalog, without checkout or payment. It uses external image URLs and Google Fonts, so those require an internet connection. Admin data stored in localStorage is browser-local and is not shared between visitors. The sample social links need to be updated before publication.
